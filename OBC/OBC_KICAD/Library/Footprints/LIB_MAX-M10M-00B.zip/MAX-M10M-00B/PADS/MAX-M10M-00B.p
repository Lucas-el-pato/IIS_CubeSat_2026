*PADS-LIBRARY-PART-TYPES-V9*

MAX-M10M-00B MAXM10M00B I ANA 7 1 0 0 0
TIMESTAMP 2026.02.21.18.10.34
"Mouser Part Number" 377-MAX-M10M-00B
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/u-blox/MAX-M10M-00B?qs=A6eO%252BMLsxmQGh8%2FJ1ZmexA%3D%3D
"Manufacturer_Name" u-blox
"Manufacturer_Part_Number" MAX-M10M-00B
"Description" GPS Modules u-blox M10 GNSS LCC module, firmware in ROM, crystal oscillator
"Datasheet Link" https://content.u-blox.com/sites/default/files/documents/MAX-M10M_IntegrationManual_UBX-22038241.pdf
"Geometry.Height" 2.7mm
GATE 1 18 0
MAX-M10M-00B
1 0 U GND_1
2 0 U TXD
3 0 U RXD
4 0 U TIMEPULSE
5 0 U EXTINT
6 0 U V_BCKP
7 0 U V_IO
8 0 U VCC
9 0 U RESET_N
10 0 U GND_2
11 0 U RF_IN
12 0 U GND_3
13 0 U LNA_EN
14 0 U VCC_RF
15 0 U VIO_SEL
16 0 U SDA
17 0 U SCL
18 0 U SAFEBOOT_N

*END*
*REMARK* SamacSys ECAD Model
16154712/1903284/2.50/18/3/Integrated Circuit
